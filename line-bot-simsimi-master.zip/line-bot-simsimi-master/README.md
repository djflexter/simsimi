# LINE@ BOT SimSimi

More Info :

https://www.ilyasafr.net/2017/05/cara-membuat-bot-line-simsimi.html

https://www.youtube.com/watch?v=IUhH4qZfXoQ
